package com.techm.learning.controller;

import org.springframework.stereotype.Controller;


@Controller
public class UserController {
	
	//Methods related to User related functionality will go here.

}
